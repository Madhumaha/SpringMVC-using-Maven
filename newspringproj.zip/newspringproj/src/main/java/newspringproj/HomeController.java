package newspringproj;



import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.servlet.ModelAndView;


@Controller
public class HomeController {
	
	
	
	@RequestMapping("/")
	public String home()
	{
		//ModelAndView mv = new ModelAndView("index");
		return "home";
	}

	

	@RequestMapping(value="/prod1", method = RequestMethod.GET)
		public ModelAndView prod1(){
		ModelAndView mv = new ModelAndView("prod");
			mv.addObject("id", 1);
			mv.addObject("name","Guitar");
		
				
	    return mv;
		
	}
	
	@RequestMapping(value="/prod2", method = RequestMethod.GET)
	public ModelAndView prod2(){
	ModelAndView mv = new ModelAndView("prod");
		mv.addObject("id", 2);
		mv.addObject("name","Violin");
	
			
    return mv;
	
} 
	
	@RequestMapping(value="/prod3", method = RequestMethod.GET)
	public ModelAndView prod3(){
	ModelAndView mv = new ModelAndView("prod");
		mv.addObject("id", 3);
		mv.addObject("name","Piano");
	
			
    return mv;
	
} 
	
	/*@RequestMapping("/allprod")
	public ModelAndView allpr()
	{
		ModelAndView mv = new ModelAndView("allprod");
		mv.addObject("id", 1);
		mv.addObject("name","Guitar");
		
		mv.addObject("id1", 2);
		mv.addObject("name1","Violin");
	
		mv.addObject("id2", 3);
		mv.addObject("name2","Piano");
		return mv;
	}*/
	
	@RequestMapping("/allprod")
	public String angl()
	{
		return "allprod";
	}
	
	@RequestMapping("/reg")
	public String registration()
	{
		return "reg";
	}
	
	@RequestMapping("/login")
	public String login()
	{
		return "login";
	}
}
